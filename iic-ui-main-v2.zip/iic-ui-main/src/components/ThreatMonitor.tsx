import React, { useState, useEffect } from 'react';
import { AlertTriangle, Shield, Target, Globe, Clock, MapPin } from 'lucide-react';

interface ThreatMonitorProps {
  dashboardState: {
    threatLevel: string;
    networkStatus: string;
    activeThreats: number;
    blockedAttacks: number;
    networkHealth: number;
    systemMode: string;
  };
}

interface ThreatEvent {
  id: string;
  type: 'malware' | 'ddos' | 'intrusion' | 'phishing' | 'ransomware';
  severity: 'low' | 'medium' | 'high' | 'critical';
  source: string;
  target: string;
  location: string;
  timestamp: Date;
  status: 'active' | 'blocked' | 'mitigated';
  description: string;
}


  const [riskData, setRiskData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchRisk = async () => {
      try {
        const res = await fetch('http://localhost:5000/api/latest-risk');
        const data = await res.json();
        setRiskData(data);
        setLoading(false);
      } catch (e) {
        setError('Could not fetch risk data');
        setLoading(false);
      }
    };
    fetchRisk();
    const interval = setInterval(fetchRisk, 3000);
    return () => clearInterval(interval);
  }, []);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-green-400 bg-green-400/10 border-green-400/20';
      case 'medium': return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20';
      case 'high': return 'text-orange-400 bg-orange-400/10 border-orange-400/20';
      case 'critical': return 'text-red-400 bg-red-400/10 border-red-400/20';
      default: return 'text-gray-400 bg-gray-400/10 border-gray-400/20';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-red-400 bg-red-400/10';
      case 'blocked': return 'text-green-400 bg-green-400/10';
      case 'mitigated': return 'text-blue-400 bg-blue-400/10';
      default: return 'text-gray-400 bg-gray-400/10';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'malware': return AlertTriangle;
      case 'ddos': return Target;
      case 'intrusion': return Shield;
      case 'phishing': return Globe;
      case 'ransomware': return AlertTriangle;
      default: return AlertTriangle;
    }
  };


  if (loading) {
    return <div className="bg-gray-800 rounded-lg border border-gray-700 p-6 text-center">Loading threat monitor...</div>;
  }
  if (error) {
    return <div className="bg-gray-800 rounded-lg border border-gray-700 p-6 text-center text-red-400">{error}</div>;
  }
  if (!riskData) {
    return <div className="bg-gray-800 rounded-lg border border-gray-700 p-6 text-center">No risk data available.</div>;
  }

  // STRIKE: Show risk label, factor, action, and raw data as threat event
  return (
    <div className="bg-gray-800 rounded-lg border border-gray-700">
      <div className="p-6 border-b border-gray-700">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5 text-red-400" />
            <span>STRIKE Threat Monitor</span>
          </h2>
          <div className="flex items-center space-x-2">
            <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-gray-400">Live Feed</span>
          </div>
        </div>
      </div>
      <div className="p-6">
        <div className="mb-4">
          <p className="text-lg font-bold">Risk Level: <span className="capitalize">{riskData.risk_label}</span></p>
          <p className="text-md">Risk Factor: <span className="font-mono">{riskData.risk_factor?.toFixed(2)}</span></p>
          <p className="text-md">Action: <span className="font-bold">{riskData.action}</span></p>
        </div>
        <div className="mt-4">
          <h3 className="text-md font-semibold mb-2">Raw Data Point:</h3>
          <div className="bg-gray-700 rounded p-2 text-xs overflow-x-auto">
            {Object.entries(riskData.row || {}).map(([key, value]) => (
              <div key={key} className="flex justify-between"><span className="font-bold">{key}:</span> <span>{String(value)}</span></div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};