import React, { useState, useEffect } from 'react';
import { Search, Filter, Calendar, AlertCircle, CheckCircle, XCircle } from 'lucide-react';

interface EventDetectionProps {
  dashboardState: {
    threatLevel: string;
    networkStatus: string;
    activeThreats: number;
    blockedAttacks: number;
    networkHealth: number;
    systemMode: string;
  };
}

interface SecurityEvent {
  id: string;
  category: 'authentication' | 'network' | 'malware' | 'data' | 'system';
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  source: string;
  timestamp: Date;
  status: 'investigating' | 'resolved' | 'false_positive';
  correlationId?: string;
}


  const [riskData, setRiskData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchRisk = async () => {
      try {
        const res = await fetch('http://localhost:5000/api/latest-risk');
        const data = await res.json();
        setRiskData(data);
        setLoading(false);
      } catch (e) {
        setError('Could not fetch risk data');
        setLoading(false);
      }
    };
    fetchRisk();
    const interval = setInterval(fetchRisk, 3000);
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return <div className="bg-gray-800 rounded-lg border border-gray-700 p-6 text-center">Loading event detection...</div>;
  }
  if (error) {
    return <div className="bg-gray-800 rounded-lg border border-gray-700 p-6 text-center text-red-400">{error}</div>;
  }
  if (!riskData) {
    return <div className="bg-gray-800 rounded-lg border border-gray-700 p-6 text-center">No event data available.</div>;
  }

  // STRIKE: Show risk label, factor, action, and raw data as event
  return (
    <div className="bg-gray-800 rounded-lg border border-gray-700">
      <div className="p-6 border-b border-gray-700">
        <h2 className="text-xl font-bold text-white flex items-center space-x-2">
          <Search className="h-5 w-5 text-blue-400" />
          <span>STRIKE Event Detection</span>
        </h2>
      </div>
      <div className="p-6">
        <div className="mb-4">
          <p className="text-lg font-bold">Risk Level: <span className="capitalize">{riskData.risk_label}</span></p>
          <p className="text-md">Risk Factor: <span className="font-mono">{riskData.risk_factor?.toFixed(2)}</span></p>
          <p className="text-md">Action: <span className="font-bold">{riskData.action}</span></p>
        </div>
        <div className="mt-4">
          <h3 className="text-md font-semibold mb-2">Raw Data Point:</h3>
          <div className="bg-gray-700 rounded p-2 text-xs overflow-x-auto">
            {Object.entries(riskData.row || {}).map(([key, value]) => (
              <div key={key} className="flex justify-between"><span className="font-bold">{key}:</span> <span>{String(value)}</span></div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};