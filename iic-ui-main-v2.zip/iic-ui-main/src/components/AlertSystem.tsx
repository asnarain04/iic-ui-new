import React, { useState, useEffect } from 'react';
import { Bell, AlertTriangle, Info, CheckCircle, X } from 'lucide-react';

interface Alert {
  id: string;
  type: 'info' | 'warning' | 'error' | 'success';
  title: string;
  message: string;
  timestamp: Date;
  dismissed: boolean;
  actionRequired: boolean;
}

export const AlertSystem: React.FC = () => {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [showDismissed, setShowDismissed] = useState(false);

  useEffect(() => {
    // Initialize with sample alerts
    const initialAlerts: Alert[] = [
      {
        id: '1',
        type: 'error',
        title: 'Critical Threat Detected',
        message: 'Advanced persistent threat identified in network segment 192.168.1.0/24',
        timestamp: new Date(),
        dismissed: false,
        actionRequired: true
      },
      {
        id: '2',
        type: 'warning',
        title: 'High Resource Usage',
        message: 'Database server CPU usage above 90% for 10 minutes',
        timestamp: new Date(Date.now() - 300000),
        dismissed: false,
        actionRequired: false
      },
      {
        id: '3',
        type: 'info',
        title: 'System Update Available',
        message: 'Security patch available for firewall firmware',
        timestamp: new Date(Date.now() - 600000),
        dismissed: false,
        actionRequired: false
      },
      {
        id: '4',
        type: 'success',
        title: 'Threat Neutralized',
        message: 'Malware threat successfully quarantined and removed',
        timestamp: new Date(Date.now() - 900000),
        dismissed: false,
        actionRequired: false
      }
    ];

    setAlerts(initialAlerts);

    // Simulate new alerts
    const interval = setInterval(() => {
      if (Math.random() < 0.2) {
        const types: Alert['type'][] = ['info', 'warning', 'error', 'success'];
        const newAlert: Alert = {
          id: Math.random().toString(36).substr(2, 9),
          type: types[Math.floor(Math.random() * types.length)],
          title: 'New Alert Generated',
          message: 'Automated monitoring system has generated a new alert',
          timestamp: new Date(),
          dismissed: false,
          actionRequired: Math.random() < 0.3
        };
        setAlerts(prev => [newAlert, ...prev.slice(0, 9)]);
      }
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  const dismissAlert = (id: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === id ? { ...alert, dismissed: true } : alert
    ));
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'error': return AlertTriangle;
      case 'warning': return AlertTriangle;
      case 'info': return Info;
      case 'success': return CheckCircle;
      default: return Info;
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'error': return 'border-red-500 bg-red-500/10 text-red-400';
      case 'warning': return 'border-yellow-500 bg-yellow-500/10 text-yellow-400';
      case 'info': return 'border-blue-500 bg-blue-500/10 text-blue-400';
      case 'success': return 'border-green-500 bg-green-500/10 text-green-400';
      default: return 'border-gray-500 bg-gray-500/10 text-gray-400';
    }
  };

  const visibleAlerts = alerts.filter(alert => showDismissed || !alert.dismissed);
  const activeAlerts = alerts.filter(alert => !alert.dismissed);
  const criticalAlerts = activeAlerts.filter(alert => alert.type === 'error');

  return (
    <div className="bg-gray-800 rounded-lg border border-gray-700">
      <div className="p-6 border-b border-gray-700">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Bell className="h-5 w-5 text-blue-400" />
            <span>Alert System</span>
          </h2>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-400">Active:</span>
              <span className="font-bold text-white">{activeAlerts.length}</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-400">Critical:</span>
              <span className="font-bold text-red-400">{criticalAlerts.length}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Toggle */}
        <div className="mb-4">
          <button
            onClick={() => setShowDismissed(!showDismissed)}
            className="text-sm text-blue-400 hover:text-blue-300 transition-colors"
          >
            {showDismissed ? 'Hide' : 'Show'} dismissed alerts
          </button>
        </div>

        {/* Alert List */}
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {visibleAlerts.map((alert) => {
            const IconComponent = getAlertIcon(alert.type);
            return (
              <div
                key={alert.id}
                className={`border rounded-lg p-4 ${getAlertColor(alert.type)} ${
                  alert.dismissed ? 'opacity-50' : ''
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <IconComponent className="h-5 w-5 mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className="font-medium text-white">{alert.title}</h3>
                        {alert.actionRequired && (
                          <span className="px-2 py-1 text-xs bg-red-600 text-red-100 rounded-full">
                            Action Required
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-300 mb-2">{alert.message}</p>
                      <p className="text-xs text-gray-500">
                        {alert.timestamp.toLocaleString()}
                      </p>
                    </div>
                  </div>
                  {!alert.dismissed && (
                    <button
                      onClick={() => dismissAlert(alert.id)}
                      className="text-gray-400 hover:text-gray-300 transition-colors"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};