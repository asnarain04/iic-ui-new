import React from 'react';
import { TrendingUp, TrendingDown, Shield, AlertTriangle, Activity, Zap } from 'lucide-react';

interface MetricsOverviewProps {
  dashboardState: {
    threatLevel: string;
    networkStatus: string;
    activeThreats: number;
    blockedAttacks: number;
    networkHealth: number;
    systemMode: string;
  };
}


export const MetricsOverview: React.FC<MetricsOverviewProps> = ({ dashboardState }) => {
  const [riskData, setRiskData] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    const fetchRisk = async () => {
      try {
        const res = await fetch('http://localhost:5000/api/latest-risk');
        const data = await res.json();
        setRiskData(data);
        setLoading(false);
      } catch (e) {
        setError('Could not fetch risk data');
        setLoading(false);
      }
    };
    fetchRisk();
    const interval = setInterval(fetchRisk, 3000);
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"><div className="bg-gray-800 rounded-lg p-6 border border-gray-700 text-center">Loading metrics...</div></div>;
  }
  if (error) {
    return <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"><div className="bg-gray-800 rounded-lg p-6 border border-gray-700 text-center text-red-400">{error}</div></div>;
  }
  if (!riskData) {
    return <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"><div className="bg-gray-800 rounded-lg p-6 border border-gray-700 text-center">No metrics available.</div></div>;
  }

  // STRIKE metrics
  const metrics = [
    {
      title: 'STRIKE Risk Level',
      value: riskData.risk_label,
      change: '',
      trend: '',
      icon: AlertTriangle,
      color: 'text-red-400',
      bgColor: 'bg-red-400/10'
    },
    {
      title: 'Risk Factor',
      value: riskData.risk_factor?.toFixed(2),
      change: '',
      trend: '',
      icon: Shield,
      color: 'text-green-400',
      bgColor: 'bg-green-400/10'
    },
    {
      title: 'Segmentation Action',
      value: riskData.action,
      change: '',
      trend: '',
      icon: Zap,
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10'
    },
    {
      title: 'Data Index',
      value: String(riskData.index),
      change: '',
      trend: '',
      icon: Activity,
      color: 'text-purple-400',
      bgColor: 'bg-purple-400/10'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {metrics.map((metric, index) => (
        <div key={index} className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className={`p-3 rounded-lg ${metric.bgColor}`}> 
              <metric.icon className={`h-6 w-6 ${metric.color}`} />
            </div>
            <div className="flex items-center space-x-1">
              {metric.trend === 'up' && <TrendingUp className="h-4 w-4 text-green-400" />}
              {metric.trend === 'down' && <TrendingDown className="h-4 w-4 text-red-400" />}
              <span className={`text-sm font-medium ${
                metric.trend === 'up' ? 'text-green-400' : 
                metric.trend === 'down' ? 'text-red-400' : 'text-gray-400'
              }`}>
                {metric.change}
              </span>
            </div>
          </div>
          <h3 className="text-3xl font-bold text-white mb-2">{metric.value}</h3>
          <p className="text-gray-400 text-sm">{metric.title}</p>
        </div>
      ))}
    </div>
  );
};