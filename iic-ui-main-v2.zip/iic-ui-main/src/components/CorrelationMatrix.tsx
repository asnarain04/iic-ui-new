import React, { useState, useEffect } from 'react';
import { Grid, TrendingUp, Filter } from 'lucide-react';

interface CorrelationMatrixProps {
  dashboardState: {
    threatLevel: string;
    networkStatus: string;
    activeThreats: number;
    blockedAttacks: number;
    networkHealth: number;
    systemMode: string;
  };
}

interface FeatureCorrelation {
  feature1: string;
  feature2: string;
  correlation: number;
}

export const CorrelationMatrix: React.FC<CorrelationMatrixProps> = ({ dashboardState }) => {
  const [latestRisk, setLatestRisk] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [correlations, setCorrelations] = useState<FeatureCorrelation[]>([]);
  const [selectedFeature, setSelectedFeature] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    const fetchRisk = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch('http://localhost:5000/api/latest-risk');
        if (!res.ok) throw new Error('Failed to fetch risk data');
        const data = await res.json();
        if (isMounted) {
          setLatestRisk(data);
          // Compute correlations from row data if possible
          if (data.row) {
            const keys = Object.keys(data.row).filter(k => typeof data.row[k] === 'number');
            const corrData: FeatureCorrelation[] = [];
            for (let i = 0; i < keys.length; i++) {
              for (let j = 0; j < keys.length; j++) {
                const feature1 = keys[i];
                const feature2 = keys[j];
                let correlation = 1.0;
                if (i !== j) {
                  // Fake correlation for demo: difference normalized
                  const v1 = data.row[feature1];
                  const v2 = data.row[feature2];
                  correlation = Math.max(-1, Math.min(1, (v1 - v2) / (Math.abs(v1) + Math.abs(v2) + 1e-8)));
                }
                corrData.push({ feature1, feature2, correlation });
              }
            }
            setCorrelations(corrData);
          }
        }
      } catch (err: any) {
        setError(err.message || 'Error fetching risk data');
      } finally {
        setLoading(false);
      }
    };
    fetchRisk();
    const interval = setInterval(fetchRisk, 3000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  const getCorrelationColor = (correlation: number) => {
    const intensity = Math.abs(correlation);
    if (correlation > 0) {
      return `rgba(239, 68, 68, ${intensity})`;
    } else {
      return `rgba(59, 130, 246, ${intensity})`;
    }
  };
  const getCorrelationValue = (feature1: string, feature2: string) => {
    const correlation = correlations.find(c => 
      (c.feature1 === feature1 && c.feature2 === feature2) ||
      (c.feature1 === feature2 && c.feature2 === feature1)
    );
    return correlation?.correlation || 0;
  };
  const getStrongCorrelations = () => {
    return correlations
      .filter(c => c.feature1 !== c.feature2 && Math.abs(c.correlation) > 0.5)
      .sort((a, b) => Math.abs(b.correlation) - Math.abs(a.correlation))
      .slice(0, 10);
  };
  const strongCorrelations = getStrongCorrelations();

  return (
    <div className="bg-gray-800 rounded-lg border border-gray-700">
      <div className="p-6 border-b border-gray-700">
        <h2 className="text-xl font-bold text-white flex items-center space-x-2">
          <Grid className="h-5 w-5 text-blue-400" />
          <span>Feature Correlation Matrix</span>
        </h2>
      </div>
      <div className="p-6">
        {loading ? (
          <div className="text-center text-gray-400">Loading real-time correlation data...</div>
        ) : error ? (
          <div className="text-center text-red-400">{error}</div>
        ) : latestRisk && correlations.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Correlation Heatmap */}
            <div className="lg:col-span-2">
              <h3 className="text-lg font-bold text-white mb-4">Correlation Heatmap</h3>
              <div className="bg-gray-700 rounded-lg p-4 overflow-x-auto">
                <div className="grid" style={{ gridTemplateColumns: `repeat(${correlations.length > 0 ? Math.sqrt(correlations.length) + 1 : 1}, minmax(60px, 1fr))` }}>
                  <div></div>
                  {Array.from(new Set(correlations.map(c => c.feature1))).map((feature, index) => (
                    <div
                      key={`header-${index}`}
                      className="text-xs text-gray-300 p-2 text-center transform -rotate-45 origin-center"
                      style={{ minWidth: '60px', height: '60px' }}
                    >
                      {feature.replace('_', ' ')}
                    </div>
                  ))}
                  {Array.from(new Set(correlations.map(c => c.feature1))).map((rowFeature, rowIndex) => (
                    <React.Fragment key={`row-${rowIndex}`}>
                      <div className="text-xs text-gray-300 p-2 text-right pr-4">
                        {rowFeature.replace('_', ' ')}
                      </div>
                      {Array.from(new Set(correlations.map(c => c.feature2))).map((colFeature, colIndex) => {
                        const correlation = getCorrelationValue(rowFeature, colFeature);
                        return (
                          <div
                            key={`cell-${rowIndex}-${colIndex}`}
                            className="w-12 h-12 flex items-center justify-center text-xs font-bold text-white cursor-pointer hover:scale-110 transition-transform rounded"
                            style={{ backgroundColor: getCorrelationColor(correlation) }}
                            onClick={() => setSelectedFeature(rowFeature)}
                            title={`${rowFeature} vs ${colFeature}: ${correlation.toFixed(3)}`}
                          >
                            {correlation.toFixed(2)}
                          </div>
                        );
                      })}
                    </React.Fragment>
                  ))}
                </div>
              </div>
              {/* Legend */}
              <div className="mt-4 flex items-center justify-center space-x-4">
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-blue-500 rounded"></div>
                  <span className="text-sm text-gray-400">Negative Correlation</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-gray-600 rounded"></div>
                  <span className="text-sm text-gray-400">No Correlation</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-red-500 rounded"></div>
                  <span className="text-sm text-gray-400">Positive Correlation</span>
                </div>
              </div>
            </div>
            {/* Strong Correlations */}
            <div>
              <h3 className="text-lg font-bold text-white mb-4">Strong Correlations</h3>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {strongCorrelations.map((correlation, index) => (
                  <div key={index} className="bg-gray-700 rounded-lg p-3">
                    <div className="flex items-center justify-between mb-2">
                      <TrendingUp className={`h-4 w-4 ${
                        correlation.correlation > 0 ? 'text-red-400' : 'text-blue-400'
                      }`} />
                      <span className={`font-bold ${
                        correlation.correlation > 0 ? 'text-red-400' : 'text-blue-400'
                      }`}>
                        {correlation.correlation.toFixed(3)}
                      </span>
                    </div>
                    <div className="text-sm">
                      <p className="text-white font-medium">
                        {correlation.feature1.replace('_', ' ')}
                      </p>
                      <p className="text-gray-400 text-xs">correlates with</p>
                      <p className="text-white font-medium">
                        {correlation.feature2.replace('_', ' ')}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              {/* Selected Feature Analysis */}
              {selectedFeature && (
                <div className="mt-6 bg-gray-700 rounded-lg p-4">
                  <h4 className="text-md font-bold text-white mb-3">
                    {selectedFeature.replace('_', ' ')} Analysis
                  </h4>
                  <div className="space-y-2">
                    {Array.from(new Set(correlations.map(c => c.feature2))).filter(f => f !== selectedFeature).map(feature => {
                      const correlation = getCorrelationValue(selectedFeature, feature);
                      return (
                        <div key={feature} className="flex items-center justify-between">
                          <span className="text-sm text-gray-300">
                            {feature.replace('_', ' ')}
                          </span>
                          <span className={`text-sm font-bold ${
                            Math.abs(correlation) > 0.5 ? 
                              (correlation > 0 ? 'text-red-400' : 'text-blue-400') : 
                              'text-gray-400'
                          }`}>
                            {correlation.toFixed(3)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
          {/* STRIKE Model Info */}
          <div className="mt-6">
            <h3 className="text-lg font-bold text-white mb-4">STRIKE Model Output</h3>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="bg-gray-700 rounded-lg p-4">
                <span className="text-sm text-gray-400">Risk Factor</span>
                <p className="text-lg font-bold text-white">{latestRisk.risk_factor?.toFixed(4)}</p>
              </div>
              <div className="bg-gray-700 rounded-lg p-4">
                <span className="text-sm text-gray-400">Risk Label</span>
                <p className="text-lg font-bold text-white">{latestRisk.risk_label}</p>
              </div>
              <div className="bg-gray-700 rounded-lg p-4">
                <span className="text-sm text-gray-400">Action</span>
                <p className="text-lg font-bold text-white">{latestRisk.action}</p>
              </div>
              <div className="bg-gray-700 rounded-lg p-4">
                <span className="text-sm text-gray-400">Data Index</span>
                <p className="text-lg font-bold text-white">{latestRisk.index}</p>
              </div>
            </div>
            <div className="bg-gray-700 rounded-lg p-4 overflow-x-auto">
              <table className="min-w-full text-xs">
                <thead>
                  <tr>
                    {latestRisk.row && Object.keys(latestRisk.row).map((key) => (
                      <th key={key} className="px-2 py-1 text-gray-400 text-left">{key}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    {latestRisk.row && Object.values(latestRisk.row).map((val, idx) => (
                      <td key={idx} className="px-2 py-1 text-white">{String(val)}</td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="text-center text-gray-400">No data available.</div>
        )}
      </div>
    </div>
  );
};