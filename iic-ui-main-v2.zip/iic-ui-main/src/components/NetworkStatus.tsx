import React, { useState, useEffect } from 'react';
import { Activity, Server, Globe, Wifi, Database, Shield } from 'lucide-react';

interface NetworkStatusProps {
  dashboardState: {
    threatLevel: string;
    networkStatus: string;
    activeThreats: number;
    blockedAttacks: number;
    networkHealth: number;
    systemMode: string;
  };
}

interface NetworkNode {
  id: string;
  name: string;
  type: 'server' | 'workstation' | 'router' | 'database' | 'firewall';
  status: 'online' | 'offline' | 'warning' | 'critical';
  load: number;
  connections: number;
  lastSeen: Date;
}


export const NetworkStatus: React.FC<NetworkStatusProps> = ({ dashboardState }) => {
  const [riskData, setRiskData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchRisk = async () => {
      try {
        const res = await fetch('http://localhost:5000/api/latest-risk');
        const data = await res.json();
        setRiskData(data);
        setLoading(false);
      } catch (e) {
        setError('Could not fetch risk data');
        setLoading(false);
      }
    };
    fetchRisk();
    const interval = setInterval(fetchRisk, 3000);
    return () => clearInterval(interval);
  }, []);

  const getNodeIcon = (type: string) => {
    switch (type) {
      case 'server': return Server;
      case 'workstation': return Globe;
      case 'router': return Wifi;
      case 'database': return Database;
      case 'firewall': return Shield;
      default: return Server;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'text-green-400 bg-green-400/10 border-green-400/20';
      case 'offline': return 'text-gray-400 bg-gray-400/10 border-gray-400/20';
      case 'warning': return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20';
      case 'critical': return 'text-red-400 bg-red-400/10 border-red-400/20';
      default: return 'text-gray-400 bg-gray-400/10 border-gray-400/20';
    }
  };

  const getLoadColor = (load: number) => {
    if (load < 50) return 'text-green-400';
    if (load < 80) return 'text-yellow-400';
    return 'text-red-400';
  };

  if (loading) {
    return <div className="bg-gray-800 rounded-lg border border-gray-700 p-6 text-center">Loading network status...</div>;
  }
  if (error) {
    return <div className="bg-gray-800 rounded-lg border border-gray-700 p-6 text-center text-red-400">{error}</div>;
  }
  if (!riskData) {
    return <div className="bg-gray-800 rounded-lg border border-gray-700 p-6 text-center">No risk data available.</div>;
  }

  // Example: show risk label, risk factor, action, and top features
  return (
    <div className="bg-gray-800 rounded-lg border border-gray-700">
      <div className="p-6 border-b border-gray-700">
        <h2 className="text-xl font-bold text-white flex items-center space-x-2">
          <Activity className="h-5 w-5 text-blue-400" />
          <span>Network Status</span>
        </h2>
      </div>
      <div className="p-6">
        <div className="mb-4">
          <p className="text-lg font-bold">Risk Level: <span className="capitalize">{riskData.risk_label}</span></p>
          <p className="text-md">Risk Factor: <span className="font-mono">{riskData.risk_factor?.toFixed(2)}</span></p>
          <p className="text-md">Action: <span className="font-bold">{riskData.action}</span></p>
        </div>
        <div className="mt-4">
          <h3 className="text-md font-semibold mb-2">Raw Data Point:</h3>
          <div className="bg-gray-700 rounded p-2 text-xs overflow-x-auto">
            {Object.entries(riskData.row || {}).map(([key, value]) => (
              <div key={key} className="flex justify-between"><span className="font-bold">{key}:</span> <span>{String(value)}</span></div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};