import React, { useState } from 'react';
import { Settings, Shield, AlertTriangle, Power, Lock, Unlock, Zap, Target } from 'lucide-react';

interface ManualControlsProps {
  dashboardState: {
    threatLevel: string;
    networkStatus: string;
    activeThreats: number;
    blockedAttacks: number;
    networkHealth: number;
    systemMode: string;
  };
  onStateChange: (state: any) => void;
}

export const ManualControls: React.FC<ManualControlsProps> = ({ dashboardState, onStateChange }) => {
  const [firewallStatus, setFirewallStatus] = useState<'enabled' | 'disabled'>('enabled');
  const [quarantineMode, setQuarantineMode] = useState<'auto' | 'manual'>('auto');
  const [threatResponse, setThreatResponse] = useState<'passive' | 'active'>('active');

  const toggleSystemMode = () => {
    const newMode = dashboardState.systemMode === 'auto' ? 'manual' : 'auto';
    onStateChange(prev => ({ ...prev, systemMode: newMode }));
  };

  const toggleFirewall = () => {
    setFirewallStatus(prev => prev === 'enabled' ? 'disabled' : 'enabled');
  };

  const emergencyLockdown = () => {
    onStateChange(prev => ({ 
      ...prev, 
      networkStatus: 'alert',
      threatLevel: 'critical',
      systemMode: 'manual'
    }));
  };

  const controls = [
    {
      title: 'System Mode',
      description: 'Switch between automatic and manual threat response',
      action: toggleSystemMode,
      status: dashboardState.systemMode,
      icon: Settings,
      color: dashboardState.systemMode === 'auto' ? 'text-green-400' : 'text-orange-400'
    },
    {
      title: 'Firewall Status',
      description: 'Enable or disable network firewall protection',
      action: toggleFirewall,
      status: firewallStatus,
      icon: Shield,
      color: firewallStatus === 'enabled' ? 'text-green-400' : 'text-red-400'
    },
    {
      title: 'Threat Response',
      description: 'Configure automated threat response behavior',
      action: () => setThreatResponse(prev => prev === 'active' ? 'passive' : 'active'),
      status: threatResponse,
      icon: Zap,
      color: threatResponse === 'active' ? 'text-blue-400' : 'text-gray-400'
    },
    {
      title: 'Quarantine Mode',
      description: 'Control isolation of suspected threats',
      action: () => setQuarantineMode(prev => prev === 'auto' ? 'manual' : 'auto'),
      status: quarantineMode,
      icon: Lock,
      color: quarantineMode === 'auto' ? 'text-green-400' : 'text-yellow-400'
    }
  ];

  return (
    <div className="bg-gray-800 rounded-lg border border-gray-700">
      <div className="p-6 border-b border-gray-700">
        <h2 className="text-xl font-bold text-white flex items-center space-x-2">
          <Settings className="h-5 w-5 text-blue-400" />
          <span>Manual Controls</span>
        </h2>
      </div>

      <div className="p-6 space-y-4">
        {controls.map((control, index) => (
          <div key={index} className="bg-gray-700 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-3">
                <control.icon className={`h-5 w-5 ${control.color}`} />
                <div>
                  <h3 className="font-medium text-white">{control.title}</h3>
                  <p className="text-sm text-gray-400">{control.description}</p>
                </div>
              </div>
              <button
                onClick={control.action}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                  control.status === 'enabled' || control.status === 'auto' || control.status === 'active'
                    ? 'bg-green-600 text-green-100 hover:bg-green-700'
                    : 'bg-gray-600 text-gray-100 hover:bg-gray-500'
                }`}
              >
                {control.status.toUpperCase()}
              </button>
            </div>
          </div>
        ))}

        {/* Emergency Controls */}
        <div className="border-t border-gray-600 pt-4">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5 text-red-400" />
            <span>Emergency Controls</span>
          </h3>
          
          <div className="space-y-3">
            <button
              onClick={emergencyLockdown}
              className="w-full bg-red-600 hover:bg-red-700 text-white py-3 px-4 rounded-lg transition-colors flex items-center justify-center space-x-2"
            >
              <Power className="h-5 w-5" />
              <span>Emergency Lockdown</span>
            </button>
            
            <button className="w-full bg-orange-600 hover:bg-orange-700 text-white py-3 px-4 rounded-lg transition-colors flex items-center justify-center space-x-2">
              <Target className="h-5 w-5" />
              <span>Isolate Compromised Systems</span>
            </button>
            
            <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg transition-colors flex items-center justify-center space-x-2">
              <Unlock className="h-5 w-5" />
              <span>Release Quarantine</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};