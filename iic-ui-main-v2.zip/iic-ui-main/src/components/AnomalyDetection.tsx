import React, { useState, useEffect } from 'react';
import { Brain, TrendingUp, BarChart3, Activity, AlertTriangle } from 'lucide-react';

interface AnomalySession {
  id: string;
  sessionId: string;
  anomalyScore: number;
  threatLevel: 'Low Risk' | 'Medium Risk' | 'High Risk';
  sessionDuration: number;
  networkPacketSize: number;
  timestamp: Date;
  features: {
    [key: string]: number;
  };
}

interface AnomalyDetectionProps {
  dashboardState: {
    threatLevel: string;
    networkStatus: string;
    activeThreats: number;
    blockedAttacks: number;
    networkHealth: number;
    systemMode: string;
  };
}

export const AnomalyDetection: React.FC<AnomalyDetectionProps> = ({ dashboardState }) => {
  const [latestRisk, setLatestRisk] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    const fetchRisk = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch('http://localhost:5000/api/latest-risk');
        if (!res.ok) throw new Error('Failed to fetch risk data');
        const data = await res.json();
        if (isMounted) {
          setLatestRisk(data);
        }
      } catch (err: any) {
        setError(err.message || 'Error fetching risk data');
      } finally {
        setLoading(false);
      }
    };
    fetchRisk();
    const interval = setInterval(fetchRisk, 3000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  // Helper for color
  const getThreatLevelColor = (level: string) => {
    switch (level?.toLowerCase()) {
      case 'no risk': return 'text-green-400 bg-green-400/10 border-green-400/20';
      case 'little risk': return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20';
      case 'medium risk': return 'text-orange-400 bg-orange-400/10 border-orange-400/20';
      case 'high risk': return 'text-red-400 bg-red-400/10 border-red-400/20';
      case 'critical': return 'text-pink-400 bg-pink-400/10 border-pink-400/20';
      default: return 'text-gray-400 bg-gray-400/10 border-gray-400/20';
    }
  };

  return (
    <div className="bg-gray-800 rounded-lg border border-gray-700">
      <div className="p-6 border-b border-gray-700">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Brain className="h-5 w-5 text-purple-400" />
            <span>AI Anomaly Detection Engine</span>
          </h2>
          <div className="flex items-center space-x-2">
            <div className="h-2 w-2 bg-purple-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-gray-400">Neural Network Active</span>
          </div>
        </div>
      </div>
      <div className="p-6">
        {loading ? (
          <div className="text-center text-gray-400">Loading real-time anomaly data...</div>
        ) : error ? (
          <div className="text-center text-red-400">{error}</div>
        ) : latestRisk ? (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="bg-gray-700 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Activity className="h-4 w-4 text-blue-400" />
                  <span className="text-sm text-gray-400">Risk Factor</span>
                </div>
                <p className="text-lg font-bold text-white">{latestRisk.risk_factor?.toFixed(4)}</p>
              </div>
              <div className="bg-gray-700 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <TrendingUp className="h-4 w-4 text-blue-400" />
                  <span className="text-sm text-gray-400">Risk Label</span>
                </div>
                <p className={`text-lg font-bold ${getThreatLevelColor(latestRisk.risk_label)}`}>{latestRisk.risk_label}</p>
              </div>
              <div className="bg-gray-700 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <BarChart3 className="h-4 w-4 text-green-400" />
                  <span className="text-sm text-gray-400">Action</span>
                </div>
                <p className="text-lg font-bold text-white">{latestRisk.action}</p>
              </div>
              <div className="bg-gray-700 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <AlertTriangle className="h-4 w-4 text-red-400" />
                  <span className="text-sm text-gray-400">Data Index</span>
                </div>
                <p className="text-lg font-bold text-red-400">{latestRisk.index}</p>
              </div>
            </div>
            <div className="mt-6">
              <h3 className="text-lg font-bold text-white mb-4">Raw Session Data</h3>
              <div className="bg-gray-700 rounded-lg p-4 overflow-x-auto">
                <table className="min-w-full text-xs">
                  <thead>
                    <tr>
                      {latestRisk.row && Object.keys(latestRisk.row).map((key) => (
                        <th key={key} className="px-2 py-1 text-gray-400 text-left">{key}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      {latestRisk.row && Object.values(latestRisk.row).map((val, idx) => (
                        <td key={idx} className="px-2 py-1 text-white">{String(val)}</td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </>
        ) : (
          <div className="text-center text-gray-400">No data available.</div>
        )}
      </div>
    </div>
  );
};