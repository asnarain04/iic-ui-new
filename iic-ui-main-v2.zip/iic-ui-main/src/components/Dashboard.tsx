import React, { useState, useEffect } from 'react';
import { ThreatMonitor } from './ThreatMonitor';
import { NetworkStatus } from './NetworkStatus';
import { EventDetection } from './EventDetection';
import { ManualControls } from './ManualControls';
import { AlertSystem } from './AlertSystem';
import { MetricsOverview } from './MetricsOverview';
import { AnomalyDetection } from './AnomalyDetection';
import { CorrelationMatrix } from './CorrelationMatrix';
import { Shield, Activity, AlertTriangle, Settings, Users, Globe } from 'lucide-react';

interface DashboardState {
  threatLevel: 'low' | 'medium' | 'high' | 'critical';
  networkStatus: 'secure' | 'monitoring' | 'alert' | 'compromised';
  activeThreats: number;
  blockedAttacks: number;
  networkHealth: number;
  systemMode: 'auto' | 'manual';
}


export const Dashboard: React.FC = () => {
  const [dashboardState, setDashboardState] = useState<DashboardState | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [riskInfo, setRiskInfo] = useState<any>(null);

  useEffect(() => {
    const fetchRisk = async () => {
      try {
        const res = await fetch('http://localhost:5000/api/latest-risk');
        const data = await res.json();
        setRiskInfo(data);
        // Map risk info to dashboardState
        setDashboardState({
          threatLevel: (data.risk_label === 'critical' ? 'critical' : data.risk_label === 'high' ? 'high' : data.risk_label === 'medium' ? 'medium' : data.risk_label === 'little risk' ? 'low' : 'low'),
          networkStatus: (data.action === 'Isolate user/device' ? 'compromised' : data.action === 'Alert' ? 'alert' : data.action === 'Monitor' ? 'monitoring' : 'secure'),
          activeThreats: Math.round(data.risk_factor * 10),
          blockedAttacks: Math.round(data.index),
          networkHealth: Math.max(75, 100 - Math.round(data.risk_factor * 100)),
          systemMode: 'auto'
        });
      } catch (e) {
        // fallback to previous state
      }
    };
    fetchRisk();
    const timer = setInterval(() => {
      setCurrentTime(new Date());
      fetchRisk();
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  const getThreatLevelColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-500';
      case 'medium': return 'text-yellow-500';
      case 'high': return 'text-orange-500';
      case 'critical': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  const getNetworkStatusColor = (status: string) => {
    switch (status) {
      case 'secure': return 'text-green-500';
      case 'monitoring': return 'text-blue-500';
      case 'alert': return 'text-yellow-500';
      case 'compromised': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  if (!dashboardState) {
    return <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">Loading real-time risk data...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Shield className="h-8 w-8 text-blue-400" />
            <div>
              <h1 className="text-2xl font-bold">CyberShield Defense System</h1>
              <p className="text-gray-400 text-sm">Real-time Network Protection & Threat Intelligence</p>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <div className="text-right">
              <p className="text-sm text-gray-400">System Time</p>
              <p className="font-mono text-lg">{currentTime.toLocaleTimeString()}</p>
            </div>
            <div className="flex items-center space-x-2">
              <div className={`h-3 w-3 rounded-full ${dashboardState.systemMode === 'auto' ? 'bg-green-500' : 'bg-orange-500'} animate-pulse`}></div>
              <span className="text-sm font-medium">{dashboardState.systemMode.toUpperCase()} MODE</span>
            </div>
          </div>
        </div>
      </header>

      {/* Status Bar */}
      <div className="bg-gray-800 border-b border-gray-700 px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2">
              <AlertTriangle className={`h-5 w-5 ${getThreatLevelColor(dashboardState.threatLevel)}`} />
              <span className="text-sm">Threat Level: </span>
              <span className={`font-bold text-sm uppercase ${getThreatLevelColor(dashboardState.threatLevel)}`}>
                {dashboardState.threatLevel}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Activity className={`h-5 w-5 ${getNetworkStatusColor(dashboardState.networkStatus)}`} />
              <span className="text-sm">Network Status: </span>
              <span className={`font-bold text-sm uppercase ${getNetworkStatusColor(dashboardState.networkStatus)}`}>
                {dashboardState.networkStatus}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-blue-400" />
              <span className="text-sm">Active Threats: </span>
              <span className="font-bold text-sm text-red-400">{dashboardState.activeThreats}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-green-400" />
              <span className="text-sm">Blocked: </span>
              <span className="font-bold text-sm text-green-400">{dashboardState.blockedAttacks}</span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Globe className="h-5 w-5 text-blue-400" />
            <span className="text-sm">Network Health: </span>
            <span className="font-bold text-sm text-blue-400">{dashboardState.networkHealth}%</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6">
        {/* Metrics Overview */}
        <MetricsOverview dashboardState={dashboardState} />

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mt-6">
          {/* Left Column - Threat Monitor */}
          <div className="xl:col-span-2">
            <ThreatMonitor dashboardState={dashboardState} />
          </div>

          {/* Right Column - Controls */}
          <div className="space-y-6">
            <ManualControls 
              dashboardState={dashboardState} 
              onStateChange={setDashboardState} 
            />
            <AlertSystem />
          </div>
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          <NetworkStatus dashboardState={dashboardState} />
          <EventDetection dashboardState={dashboardState} />
        </div>

        {/* AI Analysis Section */}
        <div className="mt-6">
          <AnomalyDetection dashboardState={dashboardState} />
        </div>

        <div className="mt-6">
          <CorrelationMatrix dashboardState={dashboardState} />
        </div>
      </div>
    </div>
  );
};