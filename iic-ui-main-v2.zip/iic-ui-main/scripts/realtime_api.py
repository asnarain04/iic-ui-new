from flask import Flask, jsonify
import pandas as pd
import numpy as np
import joblib
import threading
import time

from flask_cors import CORS
app = Flask(__name__)
CORS(app)

# Load model and encoders
best_model = joblib.load(r'C:/Users/an8957/Downloads/strike_xgboost_model_tuned.joblib')
encoder = joblib.load(r'C:/Users/an8957/Downloads/strike_feature_encoder.joblib')
label_encoder = joblib.load(r'C:/Users/an8957/Downloads/strike_label_encoder.joblib')

# Load reference data for feature engineering
ref_df = pd.read_csv(r"C:/Users/an8957/OneDrive - AT&T Services, Inc/Desktop/iic-ui-main/scripts/data/strike_cybersecurity_intrusion_data.csv")
categorical_cols = ref_df.select_dtypes(include=['object']).columns.tolist()

# Load real-time CSV
realtime_csv = r"C:/Users/an8957/OneDrive - AT&T Services, Inc/Desktop/iic-ui-main/scripts/data/overview_sample_data_original.csv"
df_realtime = pd.read_csv(realtime_csv)

latest_result = {}
current_index = 0

# Feature engineering helper
def process_row(row):
    try:
        X_new = row.drop([
            'session_id', 'risk_label', 'analyst_feedback', 'event_timestamp',
            'mitigation_action', 'response_time_ms', 'isolation_scope',
            'false_positive_flag', 'model_confidence'
        ], errors='ignore')
        X_new['login_failed_ratio'] = X_new['failed_logins'] / (X_new['login_attempts'] + 1)
        X_new['risk_score_product'] = X_new['ip_reputation_score'] * X_new['user_risk_profile']
        X_new['duration_per_attempt'] = X_new['session_duration'] / (X_new['login_attempts'] + 1)
        X_new_df = pd.DataFrame([X_new])
        X_new_df[categorical_cols] = encoder.transform(X_new_df[categorical_cols])
        X_new_arr = X_new_df.values
        pred = best_model.predict(X_new_arr)[0]
        risk_label = label_encoder.inverse_transform([pred])[0]
        risk_probs = best_model.predict_proba(X_new_arr)[0]
        class_weight_map = {
            "no risk": 0.0,
            "little risk": 0.2,
            "medium risk": 0.4,
            "high risk": 0.8,
            "critical": 1.0
        }
        class_weights = {idx: class_weight_map.get(lbl.lower(), 0.0) for idx, lbl in enumerate(label_encoder.classes_)}
        base_risk_factor = sum([risk_probs[idx] * class_weights[idx] for idx in range(len(risk_probs))])
        importances = best_model.feature_importances_
        top_indices = np.argsort(importances)[-5:][::-1]
        top_features = [ref_df.columns[i] for i in top_indices]
        top_feature_vals = []
        for feat in top_features:
            val = X_new_df[feat].values[0]
            min_val = ref_df[feat].min()
            max_val = ref_df[feat].max()
            norm_val = (val - min_val) / (max_val - min_val + 1e-8)
            norm_val = 0.5 + 0.5 * norm_val
            top_feature_vals.append(norm_val)
        feature_modulation = np.mean(top_feature_vals)
        risk_factor = base_risk_factor * feature_modulation
        if risk_factor < 0.08:
            action = "No action"
        elif risk_factor < 0.15:
            action = "Monitor"
        elif risk_factor < 0.4:
            action = "Alert"
        else:
            action = "Isolate user/device"
        return {
            "index": int(row.name),
            "risk_label": risk_label,
            "risk_factor": float(risk_factor),
            "action": action,
            "row": row.to_dict(),
            "timestamp": time.strftime('%Y-%m-%d %H:%M:%S')
        }
    except Exception as e:
        return {
            "error": str(e),
            "index": int(row.name) if hasattr(row, 'name') else None,
            "row": row.to_dict() if hasattr(row, 'to_dict') else None
        }

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

def stream_data():
    global latest_result, current_index
    while current_index < len(df_realtime):
        row = df_realtime.iloc[current_index]
        latest_result = process_row(row)
        logging.info(f"Processed row {current_index}: {latest_result.get('risk_label', latest_result.get('error', 'N/A'))}")
        current_index += 1
        time.sleep(3)
@app.route('/api/status')
def status():
    try:
        model_ok = best_model is not None
        encoder_ok = encoder is not None
        label_encoder_ok = label_encoder is not None
        csv_ok = df_realtime is not None and len(df_realtime) > 0
        return jsonify({
            "model_loaded": model_ok,
            "encoder_loaded": encoder_ok,
            "label_encoder_loaded": label_encoder_ok,
            "csv_loaded": csv_ok,
            "current_index": current_index,
            "total_rows": len(df_realtime)
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/latest-risk')
def get_latest_risk():
    return jsonify(latest_result)

@app.route('/api/reset')
def reset_stream():
    global current_index
    current_index = 0
    return jsonify({"status": "reset"})

if __name__ == '__main__':
    t = threading.Thread(target=stream_data)
    t.daemon = True
    t.start()
    app.run(host='0.0.0.0', port=5000)
