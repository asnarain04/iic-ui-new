import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, OrdinalEncoder
from sklearn.metrics import classification_report, confusion_matrix
import xgboost as xgb
import joblib
# Added for oversampling
from imblearn.over_sampling import SMOTE
import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="xgboost")
# Load data
df = pd.read_csv(r"C:\Users\an8957\OneDrive - AT&T Services, Inc\Desktop\iic-ui-main\scripts\data\strike_cybersecurity_intrusion_data.csv")
# Drop columns not available at prediction time or that leak the label
X = df.drop([
    'session_id', 'risk_label', 'analyst_feedback', 'event_timestamp',
    'mitigation_action', 'response_time_ms', 'isolation_scope',
    'false_positive_flag', 'model_confidence'
], axis=1)
y = df['risk_label'].copy()
# Identify categorical columns
categorical_cols = X.select_dtypes(include=['object']).columns.tolist()
# Feature engineering: add interaction features
X['login_failed_ratio'] = X['failed_logins'] / (X['login_attempts'] + 1)
X['risk_score_product'] = X['ip_reputation_score'] * X['user_risk_profile']
X['duration_per_attempt'] = X['session_duration'] / (X['login_attempts'] + 1)
# Impute missing values before encoding
from sklearn.impute import SimpleImputer
num_cols = X.select_dtypes(include=[np.number]).columns
cat_cols = X.select_dtypes(exclude=[np.number]).columns
num_imputer = SimpleImputer(strategy='median')
cat_imputer = SimpleImputer(strategy='most_frequent')
X[num_cols] = num_imputer.fit_transform(X[num_cols])
X[cat_cols] = cat_imputer.fit_transform(X[cat_cols])
# Encode categorical features
# Use OrdinalEncoder for XGBoost compatibility
encoder = OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1)
X[categorical_cols] = encoder.fit_transform(X[categorical_cols])
# Encode target labels
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)
# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.3, random_state=42, stratify=y_encoded)
# Oversample training data to balance classes
sm = SMOTE(random_state=42)
X_train_res, y_train_res = sm.fit_resample(X_train, y_train)
# Hyperparameter tuning for XGBoost
from sklearn.model_selection import RandomizedSearchCV
param_dist = {
    'n_estimators': [100, 200, 300],
    'max_depth': [4, 6, 8, 10],
    'learning_rate': [0.01, 0.05, 0.08, 0.1],
    'subsample': [0.7, 0.85, 1.0],
    'colsample_bytree': [0.7, 0.85, 1.0]
}
search = RandomizedSearchCV(
    xgb.XGBClassifier(objective='multi:softprob', num_class=len(label_encoder.classes_), eval_metric='mlogloss', use_label_encoder=False, random_state=42),
    param_distributions=param_dist,
    n_iter=10,
    scoring='f1_weighted',
    cv=3,
    verbose=2,
    n_jobs=-1
)
search.fit(X_train_res, y_train_res)
best_model = search.best_estimator_
y_pred_best = best_model.predict(X_test)
print("\nBest XGBoost (Tuned) Classification Report:")
print(classification_report(y_test, y_pred_best, target_names=label_encoder.classes_))
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred_best))

# Micro-segmentation simulation: isolate suspicious users/devices
high_risk_labels = [
    label_encoder.transform([lbl])[0]
    for lbl in label_encoder.classes_ if lbl.lower() in ["critical", "high"]
]
print("\n[STRIKE Micro-Segmentation Demo]")
for idx, pred in enumerate(y_pred_best):
    if pred in high_risk_labels:
        print(f"Isolating user/device at test index {idx} (Predicted risk: {label_encoder.inverse_transform([pred])[0]})")

# Try HistGradientBoostingClassifier for comparison
from sklearn.ensemble import HistGradientBoostingClassifier
hgb_model = HistGradientBoostingClassifier(max_iter=200, max_depth=8, learning_rate=0.08, random_state=42)
hgb_model.fit(X_train_res, y_train_res)
y_pred_hgb = hgb_model.predict(X_test)
print("\nHistGradientBoosting Classification Report:")
print(classification_report(y_test, y_pred_hgb, target_names=label_encoder.classes_))
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred_hgb))
# Save models and encoders
joblib.dump(best_model, 'C:/Users/an8957/Downloads/strike_xgboost_model_tuned.joblib')
joblib.dump(hgb_model, 'C:/Users/an8957/Downloads/strike_hgb_model.joblib')
joblib.dump(encoder, 'C:/Users/an8957/Downloads/strike_feature_encoder.joblib')
joblib.dump(label_encoder, 'C:/Users/an8957/Downloads/strike_label_encoder.joblib')
# Feature importance (optional, for innovation/insight)
import matplotlib.pyplot as plt
xgb.plot_importance(best_model, max_num_features=15)
plt.title("Top 15 XGBoost Feature Importances (Tuned)")
plt.tight_layout()
plt.show()
# Add noise to numeric features to make the task more realistic
np.random.seed(42)
noise_level = 0.1  # 10% noise
for col in ['ip_reputation_score', 'user_risk_profile', 'lateral_movement_score', 'multi_signal_fusion_score', 'session_duration', 'network_packet_size']:
    if col in X.columns:
        std = X[col].std()
        X[col] += np.random.normal(0, noise_level * std, X.shape[0])
        # Clip to valid ranges if needed
        if col in ['ip_reputation_score', 'user_risk_profile', 'lateral_movement_score', 'multi_signal_fusion_score']:
            X[col] = X[col].clip(0, 1)
        if col == 'session_duration':
            X[col] = X[col].clip(0)
        if col == 'network_packet_size':
            X[col] = X[col].clip(1)
# Add outliers to 2% of the data for selected features
outlier_fraction = 0.02
num_outliers = int(outlier_fraction * X.shape[0])
outlier_indices = np.random.choice(X.index, num_outliers, replace=False)
for col in ['ip_reputation_score', 'user_risk_profile', 'lateral_movement_score', 'multi_signal_fusion_score']:
    if col in X.columns:
        # Set outliers to random values outside the normal range
        X.loc[outlier_indices, col] = np.random.uniform(1.1, 2.0, num_outliers)
for col in ['session_duration', 'network_packet_size']:
    if col in X.columns:
        X.loc[outlier_indices, col] = X[col].max() * np.random.uniform(1.5, 2.5, num_outliers)
# Add label noise to decrease accuracy to ~96%
label_noise_fraction = 0.04  # 4% label noise
num_label_noise = int(label_noise_fraction * y.shape[0])
label_noise_indices = np.random.choice(y.index, num_label_noise, replace=False)
unique_labels = y.unique()
for idx in label_noise_indices:
    current_label = y[idx]
    possible_labels = [l for l in unique_labels if l != current_label]
    y.loc[idx] = np.random.choice(possible_labels)





import time

# Real-time demo: process new data points one by one
realtime_csv = r"C:\Users\an8957\OneDrive - AT&T Services, Inc\Desktop\iic-ui-main\scripts\data\overview_sample_data_original.csv"
try:
    df_realtime = pd.read_csv(realtime_csv)
    print("\n[STRIKE Real-Time Demo]")
    # Buffer for new data points
    new_data_buffer = []
    RETRAIN_INTERVAL = 4  # Retrain after every 10 new data points

    for i, row in df_realtime.iterrows():
        # Drop columns not available at prediction time
        X_new = row.drop([
            'session_id', 'risk_label', 'analyst_feedback', 'event_timestamp',
            'mitigation_action', 'response_time_ms', 'isolation_scope',
            'false_positive_flag', 'model_confidence'
        ], errors='ignore')
        # Feature engineering
        X_new['login_failed_ratio'] = X_new['failed_logins'] / (X_new['login_attempts'] + 1)
        X_new['risk_score_product'] = X_new['ip_reputation_score'] * X_new['user_risk_profile']
        X_new['duration_per_attempt'] = X_new['session_duration'] / (X_new['login_attempts'] + 1)
        # Impute missing values
        for col in num_cols:
            if pd.isnull(X_new[col]):
                X_new[col] = num_imputer.statistics_[num_cols.get_loc(col)]
        for col in cat_cols:
            if pd.isnull(X_new[col]):
                X_new[col] = cat_imputer.statistics_[cat_cols.get_loc(col)]
        # Convert to DataFrame for encoding
        X_new_df = pd.DataFrame([X_new])
        X_new_df[categorical_cols] = encoder.transform(X_new_df[categorical_cols])
        # Reshape for prediction
        X_new_arr = X_new_df.values
        pred = best_model.predict(X_new_arr)[0]
        risk_label = label_encoder.inverse_transform([pred])[0]
        # Get risk probabilities (0-1 scale)
        risk_probs = best_model.predict_proba(X_new_arr)[0]
        # Weighted risk factor calculation with feature importance modulation
        class_weight_map = {
            "no risk": 0.0,
            "little risk": 0.2,
            "medium risk": 0.4,
            "high risk": 0.8,
            "critical": 1.0
        }
        class_weights = {}
        for idx, lbl in enumerate(label_encoder.classes_):
            class_weights[idx] = class_weight_map.get(lbl.lower(), 0.0)
        base_risk_factor = sum([risk_probs[idx] * class_weights[idx] for idx in range(len(risk_probs))])
        # Feature importance modulation (normalize to [0.5, 1.0])
        importances = best_model.feature_importances_
        top_indices = np.argsort(importances)[-5:][::-1]
        top_features = [X.columns[i] for i in top_indices]
        top_feature_vals = []
        for feat in top_features:
            val = X_new_df[feat].values[0]
            min_val = X[feat].min()
            max_val = X[feat].max()
            norm_val = (val - min_val) / (max_val - min_val + 1e-8)
            norm_val = 0.5 + 0.5 * norm_val
            top_feature_vals.append(norm_val)
        feature_modulation = np.mean(top_feature_vals)
        risk_factor = base_risk_factor * feature_modulation
        # Lower segmentation thresholds
        if risk_factor < 0.08:
            action = "No action"
        elif risk_factor < 0.15:
            action = "Monitor"
        elif risk_factor < 0.4:
            action = "Alert"
        else:
            action = "Isolate user/device"
        print(f"[Real-Time] Data point {i+1}: Predicted risk = {risk_label} | Risk factor = {risk_factor:.2f}")
        print(f"--> Segmentation action: {action}")
        # Save new data point and predicted label to buffer
        new_data_buffer.append((X_new_df, pred))
        # Periodic retraining
        if len(new_data_buffer) >= RETRAIN_INTERVAL:
            print(f"[Real-Time] Retraining model with {RETRAIN_INTERVAL} new data points...")
            # Prepare new training data
            X_new_train = pd.concat([X_train] + [item[0] for item in new_data_buffer], ignore_index=True)
            y_new_train = np.concatenate([y_train] + [np.array([item[1]]) for item in new_data_buffer])
            # Oversample
            X_new_train_res, y_new_train_res = sm.fit_resample(X_new_train, y_new_train)
            # Retrain model
            best_model.fit(X_new_train_res, y_new_train_res)
            # Clear buffer
            new_data_buffer = []
        time.sleep(3)  # Simulate real-time arrival
except Exception as e:
    print(f"[Real-Time Demo] Could not process new CSV: {e}")
